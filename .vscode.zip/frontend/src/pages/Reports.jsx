import React from 'react';

const Reports = () => {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Reports</h2>
      <p>Generate production, QA, and inventory reports here.</p>
    </div>
  );
};

export default Reports;