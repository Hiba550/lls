from django.apps import AppConfig

class AssemblyConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "backend.apps.assembly"  # Fixed the app name
